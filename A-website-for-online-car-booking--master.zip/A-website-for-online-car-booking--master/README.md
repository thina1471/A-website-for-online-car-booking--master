# A-website-for-online-car-booking-
This website is all about online car booking system.This project is done in PHP,Javascript and SQL.

I have uploaded code for only home page.

Below is the some screenshots of webiste.

Home page :

![car booking home page1](https://user-images.githubusercontent.com/26687042/47962403-5565d300-e042-11e8-90a2-0308ebdd7025.png)

![car booking home apge 2](https://user-images.githubusercontent.com/26687042/47962404-5c8ce100-e042-11e8-94e9-3a482c8a5c66.png)

![car booking home page bottom](https://user-images.githubusercontent.com/26687042/47962411-6878a300-e042-11e8-94a6-5a20029c4473.png)

When someone click on login/admin login

![car login](https://user-images.githubusercontent.com/26687042/47962409-63b3ef00-e042-11e8-91d8-a0784c88b3d6.png)

